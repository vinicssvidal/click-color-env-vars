import io
import subprocess

import pytest

import click
import click._termui_impl as termui_impl
from click.testing import CliRunner

RED = "\x1b[31m"
STYLED = click.style("hello", fg="red")


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    monkeypatch.delenv("NO_COLOR", raising=False)
    monkeypatch.delenv("FORCE_COLOR", raising=False)


class FakeTTY(io.StringIO):
    def isatty(self):
        return True


def echo_to(stream, **kwargs):
    click.echo(STYLED, file=stream, **kwargs)
    return stream.getvalue()


# ---------- echo / secho / style ----------

def test_default_behavior_unchanged():
    assert RED not in echo_to(io.StringIO())
    assert RED in echo_to(FakeTTY())


def test_no_color_disables_colors_on_tty(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    out = echo_to(FakeTTY())
    assert RED not in out
    assert "hello" in out


def test_empty_no_color_is_ignored(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "")
    assert RED in echo_to(FakeTTY())
    monkeypatch.setenv("FORCE_COLOR", "1")
    assert RED in echo_to(io.StringIO())


def test_force_color_enables_colors_on_non_tty(monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    assert RED in echo_to(io.StringIO())


def test_force_color_zero_is_ignored(monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "0")
    assert RED not in echo_to(io.StringIO())
    assert RED in echo_to(FakeTTY())


def test_no_color_wins_over_force_color(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    monkeypatch.setenv("FORCE_COLOR", "1")
    assert RED not in echo_to(FakeTTY())
    assert RED not in echo_to(io.StringIO())


def test_explicit_argument_wins(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    assert RED in echo_to(io.StringIO(), color=True)
    monkeypatch.delenv("NO_COLOR")
    monkeypatch.setenv("FORCE_COLOR", "1")
    assert RED not in echo_to(FakeTTY(), color=False)


def test_context_color_wins_including_inherited(monkeypatch):
    cmd = click.Command("cmd")
    monkeypatch.setenv("NO_COLOR", "1")
    parent = click.Context(cmd, color=True)
    child = click.Context(cmd, parent=parent)
    with child.scope():
        assert RED in echo_to(io.StringIO())
    monkeypatch.delenv("NO_COLOR")
    monkeypatch.setenv("FORCE_COLOR", "1")
    with click.Context(cmd, color=False).scope():
        assert RED not in echo_to(FakeTTY())


def test_variables_are_read_at_call_time(monkeypatch):
    assert RED not in echo_to(io.StringIO())
    monkeypatch.setenv("FORCE_COLOR", "1")
    assert RED in echo_to(io.StringIO())
    monkeypatch.setenv("NO_COLOR", "1")
    assert RED not in echo_to(io.StringIO())


def test_secho_follows_rules(monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    buf = io.StringIO()
    click.secho("hi", fg="red", file=buf)
    assert RED in buf.getvalue()


def test_style_and_unstyle_unchanged(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    assert click.style("x", fg="red") == "\x1b[31mx\x1b[0m"
    assert click.unstyle(click.style("x", fg="red")) == "x"


# ---------- progress bar ----------

def test_progressbar_colors_but_does_not_animate(monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    buf = io.StringIO()
    label = click.style("Working", fg="red")
    with click.progressbar(range(3), label=label, file=buf) as bar:
        for _ in bar:
            pass
    out = buf.getvalue()
    assert RED in out
    assert "\r" not in out


# ---------- pager ----------

class _Stdin(io.StringIO):
    def close(self):
        pass


class FakePopen:
    last = None

    def __init__(self, args, **kwargs):
        self.env = kwargs.get("env")
        self.stdin = _Stdin()
        FakePopen.last = self

    def wait(self):
        return 0

    def terminate(self):
        pass


@pytest.fixture
def fake_less(monkeypatch, tmp_path):
    monkeypatch.setattr(termui_impl, "isatty", lambda stream: True)
    monkeypatch.setattr(
        termui_impl, "which",
        lambda cmd: str(tmp_path / "less") if cmd == "less" else None,
    )
    monkeypatch.setattr(subprocess, "Popen", FakePopen)
    monkeypatch.delenv("PAGER", raising=False)
    monkeypatch.delenv("LESS", raising=False)
    monkeypatch.setenv("TERM", "xterm")
    FakePopen.last = None


def run_pager():
    click.echo_via_pager(STYLED)
    return FakePopen.last


def test_pager_force_color_still_sets_less_r(fake_less, monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    proc = run_pager()
    assert proc.env.get("LESS") == "-R"
    assert RED in proc.stdin.getvalue()


def test_pager_no_color_wins_over_less_detection(fake_less, monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    assert RED not in run_pager().stdin.getvalue()
    monkeypatch.setenv("LESS", "-R")
    assert RED not in run_pager().stdin.getvalue()


def test_pager_force_color_does_not_edit_user_less(fake_less, monkeypatch):
    monkeypatch.setenv("FORCE_COLOR", "1")
    monkeypatch.setenv("LESS", "-X")
    proc = run_pager()
    assert RED in proc.stdin.getvalue()
    assert proc.env.get("LESS") == "-X"


# ---------- CliRunner ----------

@click.command()
def styled_cmd():
    click.echo(STYLED)


def test_runner_default_strips_without_variables():
    assert RED not in CliRunner().invoke(styled_cmd).output


def test_runner_force_color_keeps_colors():
    result = CliRunner().invoke(styled_cmd, env={"FORCE_COLOR": "1"})
    assert RED in result.output


def test_runner_no_color_wins():
    result = CliRunner().invoke(
        styled_cmd, env={"NO_COLOR": "1", "FORCE_COLOR": "1"}
    )
    assert RED not in result.output


def test_runner_explicit_color_true_wins():
    result = CliRunner().invoke(styled_cmd, env={"NO_COLOR": "1"}, color=True)
    assert RED in result.output


def test_runner_env_none_removes_variable(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    result = CliRunner().invoke(
        styled_cmd, env={"NO_COLOR": None, "FORCE_COLOR": "1"}
    )
    assert RED in result.output


# ---------- prompts, help, errors ----------

def test_prompt_and_confirm_follow_rules():
    @click.command()
    def cli():
        click.prompt(click.style("Name", fg="red"))
        click.confirm(click.style("Sure", fg="red"))

    result = CliRunner().invoke(cli, input="bob\ny\n", env={"FORCE_COLOR": "1"})
    assert result.exit_code == 0
    assert result.output.count(RED) >= 2


def test_help_follows_rules():
    @click.command(epilog=click.style("Epilog", fg="red"))
    def cli():
        pass

    result = CliRunner().invoke(cli, ["--help"], env={"FORCE_COLOR": "1"})
    assert RED in result.output


def test_usage_error_follows_rules():
    @click.command()
    @click.pass_context
    def cli(ctx):
        ctx.fail(click.style("broken", fg="red"))

    result = CliRunner().invoke(cli, env={"FORCE_COLOR": "1"})
    assert result.exit_code == 2
    assert RED in result.stderr



# ---------- non-color escape codes and machine-read output ----------

import click._compat as compat_mod
import click.termui as termui_mod


def test_clear_still_clears_with_no_color(monkeypatch, capsys):
    monkeypatch.setattr(compat_mod, "isatty", lambda stream: True)
    monkeypatch.setattr(termui_mod, "isatty", lambda stream: True)
    monkeypatch.setenv("NO_COLOR", "1")
    click.clear()
    out = capsys.readouterr().out
    assert "\x1b[2J" in out
    assert "\x1b[1;1H" in out


def test_shell_completion_never_colored():
    @click.command()
    @click.option("--name", help=click.style("Name help", fg="red"))
    def cli(name):
        pass

    result = CliRunner().invoke(
        cli,
        env={
            "_CLI_COMPLETE": "zsh_complete",
            "COMP_WORDS": "cli --",
            "COMP_CWORD": "1",
            "FORCE_COLOR": "1",
        },
    )
    assert "Name help" in result.output
    assert RED not in result.output
