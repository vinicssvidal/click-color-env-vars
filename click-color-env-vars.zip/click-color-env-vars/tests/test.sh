#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /app

# F2P: hidden tests for the new behavior
env -u NO_COLOR -u FORCE_COLOR python3 -m pytest -q -p no:cacheprovider \
    --rootdir=/tests /tests/test_color_env.py
f2p=$?

# P2P: Click's own test suite (including tests the agent added)
env -u NO_COLOR -u FORCE_COLOR python3 -m pytest -q -p no:cacheprovider \
    --rootdir=/app tests/
p2p=$?

if [ "$f2p" -eq 0 ] && [ "$p2p" -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
fi
exit 0
