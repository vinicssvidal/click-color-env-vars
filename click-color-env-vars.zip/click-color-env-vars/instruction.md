Click currently decides whether to print colors from three things: an explicit color argument that some functions accept, the color setting on the current Context, and, when neither is set, whether the output stream is a terminal. I want Click to also respect the NO\_COLOR and FORCE\_COLOR environment variables, so that a user can turn colors off or on for any Click program without changing its code.



The rules are these. A non-empty NO\_COLOR turns colors off, and an empty NO\_COLOR is treated as if it were not set. A non-empty FORCE\_COLOR turns colors on even when the output is not a terminal, except that the value "0" is treated as if it were not set. If both have meaningful values, NO\_COLOR wins. The variables are only a default: an explicit color argument passed to a Click function always wins over them, and so does a color value set on a Context, including one that the Context inherited from its parent. When neither variable has a meaningful value, Click must behave exactly as it does today.



The variables must be read each time Click decides about color, not when a module is imported, because programs and tests change os.environ while they run. The decision has to be the same everywhere Click writes text that may contain styles, not only in click.echo. Find those places yourself. They include echo and secho, progress bars, echo\_via\_pager, prompts and confirmations, and help, usage and error messages. All of them must go through one shared piece of logic instead of each having its own copy of the checks.



Two places need extra care. The progress bar decides whether to animate based on whether its file is a terminal. These variables must only change whether escape codes are written, never whether the bar is shown or animated. When paging with less, Click currently looks at the LESS variable to decide whether less can display colors, and sets LESS=-R itself when LESS is empty. NO\_COLOR must win over that detection. When FORCE\_COLOR turns colors on and LESS is empty, Click must still set LESS=-R as it does today. If LESS is set without r or R, FORCE\_COLOR still sends the colors, and Click must not edit the user's LESS value.



CliRunner must follow the same rules, and its color parameter keeps its current default of False. Treat that value the way Click treats a stream that is not a terminal: without the variables the output is stripped as it is today, a meaningful FORCE\_COLOR keeps the colors, and NO\_COLOR keeps them stripped. Passing color=True is an explicit choice and wins over both variables. Variables passed through the env argument of invoke must count, including a None value, which removes a variable from the environment for that invocation.



Turning colors off must only remove colors. Some text that Click writes contains escape codes that are not colors: click.clear writes the codes that clear the screen and move the cursor, and it must keep doing that on a terminal even when NO\_COLOR is set. The opposite holds for text that is read by a program and not by a person: the output of shell completion must never contain color codes, even when FORCE\_COLOR is set and a help text was styled.



Do not change any public function signature or default value. click.style must keep returning exactly the same escape codes, and click.unstyle must keep working as before, because turning colors off must only affect what is written out. All existing tests must keep passing. Add tests for your change in the existing tests folder that cover the precedence rules, the empty and "0" values, a variable that changes after Click was imported, and the CliRunner behavior described above.

