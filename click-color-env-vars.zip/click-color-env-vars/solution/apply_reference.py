#!/usr/bin/env python3
"""Reference solution for the NO_COLOR / FORCE_COLOR task.

Run from the root of the Click 8.2.1 checkout:  python3 apply_reference.py
It stops with an error if any expected piece of code is not found.
"""
import re
import sys
from pathlib import Path

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else ".") / "src" / "click"

HELPER = '''

def _color_from_env() -> bool | None:
    """Return the color choice made through the ``NO_COLOR`` and
    ``FORCE_COLOR`` environment variables, or ``None`` when neither has a
    meaningful value. The environment is read on every call.

    A non-empty ``NO_COLOR`` disables colors and wins over ``FORCE_COLOR``.
    A non-empty ``FORCE_COLOR`` other than ``"0"`` enables colors.
    """
    import os

    if os.environ.get("NO_COLOR"):
        return False

    force_color = os.environ.get("FORCE_COLOR")

    if force_color and force_color != "0":
        return True

    return None
'''


def fail(msg):
    sys.exit(f"ERRO: {msg}")


def sub_once(text, pattern, repl, where, required=True):
    new, n = re.subn(pattern, repl, text, count=1, flags=re.M)
    if n != 1 and required:
        fail(f"trecho nao encontrado em {where}: {pattern}")
    return new


def edit_func(text, name, pattern, repl, where, required=True):
    m = re.search(rf"^def {name}\(", text, re.M)
    if not m:
        fail(f"funcao {name} nao encontrada em {where}")
    nxt = re.search(r"^(?:def |class |@)", text[m.end():], re.M)
    end = m.end() + nxt.start() if nxt else len(text)
    body = sub_once(text[m.start():end], pattern, repl, f"{where}:{name}", required)
    return text[: m.start()] + body + text[end:]


# ---------- _compat.py: the shared logic ----------
path = SRC / "_compat.py"
text = path.read_text()
if "_color_from_env" in text:
    fail("a solucao ja foi aplicada")
text = edit_func(
    text,
    "should_strip_ansi",
    r"^([ \t]*)(return not isatty\(stream\).*)$",
    "\\g<1>env_color = _color_from_env()\n"
    "\\g<1>if env_color is not None:\n"
    "\\g<1>    return not env_color\n"
    "\\g<1>\\g<2>",
    "_compat.py",
)
path.write_text(text.rstrip("\n") + "\n" + HELPER)

# ---------- testing.py: CliRunner ----------
path = SRC / "testing.py"
text = path.read_text()
text = sub_once(
    text,
    r"^([ \t]*)if color is None:\n[ \t]*return not default_color[ \t]*\n",
    "\\g<1>if color is None:\n"
    "\\g<1>    # color=True passed to invoke is an explicit choice.\n"
    "\\g<1>    if default_color:\n"
    "\\g<1>        return False\n"
    "\\g<1>    # Otherwise behave like a stream that is not a terminal.\n"
    "\\g<1>    env_color = _compat._color_from_env()\n"
    "\\g<1>    if env_color is not None:\n"
    "\\g<1>        return not env_color\n"
    "\\g<1>    return True\n",
    "testing.py",
)
if not re.search(r"^from \. import .*_compat|^from \. import _compat", text, re.M):
    fail("testing.py nao importa _compat")
path.write_text(text)

# ---------- _termui_impl.py: pagers ----------
path = SRC / "_termui_impl.py"
text = path.read_text()
text = sub_once(
    text,
    r"^(from \._compat import)",
    "from ._compat import _color_from_env\n\\g<1>",
    "_termui_impl.py (imports)",
)
text = edit_func(
    text,
    "_pipepager",
    r"^([ \t]*)(if color is None and .*less.*:)[ \t]*$",
    "\\g<1>env_color = _color_from_env() if color is None else None\n"
    "\\g<1>if env_color is False:\n"
    "\\g<1>    color = False\n\n"
    "\\g<1>\\g<2>",
    "_termui_impl.py",
)
text = edit_func(
    text,
    "_pipepager",
    r"^([ \t]*)(\w+ = subprocess\.Popen\()",
    "\\g<1># less cannot show colors with this LESS value, but FORCE_COLOR\n"
    "\\g<1># asks for them. Send them without editing the user's LESS.\n"
    "\\g<1>if color is None and env_color:\n"
    "\\g<1>    color = True\n\n"
    "\\g<1>\\g<2>",
    "_termui_impl.py",
)
for name, required in (("_nullpager", True), ("_tempfilepager", False)):
    text = edit_func(
        text,
        name,
        r"^([ \t]*)if not color:",
        "\\g<1>if color is None:\n"
        "\\g<1>    color = _color_from_env()\n"
        "\\g<1>if not color:",
        "_termui_impl.py",
        required,
    )
path.write_text(text)

print("OK: solucao aplicada em _compat.py, testing.py e _termui_impl.py")
