#!/usr/bin/env python3
"""Second part of the reference solution (clear and shell completion).

Run from the root of the Click checkout AFTER apply_reference.py.
"""
import re
import sys
from pathlib import Path

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else ".") / "src" / "click"


def fail(msg):
    sys.exit(f"ERRO: {msg}")


def edit_func(text, name, pattern, repl, where, count):
    m = re.search(rf"^def {name}\(", text, re.M)
    if not m:
        fail(f"funcao {name} nao encontrada em {where}")
    nxt = re.search(r"^(?:def |class |@)", text[m.end():], re.M)
    end = m.end() + nxt.start() if nxt else len(text)
    body, n = re.subn(pattern, repl, text[m.start():end], flags=re.M)
    if n != count:
        fail(f"esperava {count} trecho(s) em {where}:{name}, achei {n}")
    return text[: m.start()] + body + text[end:]


# clear(): the screen codes are not colors, NO_COLOR must not strip them.
path = SRC / "termui.py"
text = path.read_text()
if "color=True)" in text.split("def clear(")[1].split("\ndef ")[0]:
    fail("a solucao extra ja foi aplicada")
text = edit_func(
    text, "clear",
    r"^([ \t]*echo\(.*nl=False)\)[ \t]*$",
    "\\g<1>, color=True)",
    "termui.py", 1,
)
path.write_text(text)

# Shell completion output is read by the shell: never send colors.
path = SRC / "shell_completion.py"
text = path.read_text()
text = edit_func(
    text, "shell_complete",
    r"^([ \t]*)echo\(comp\.(source|complete)\(\)\)[ \t]*$",
    "\\g<1>echo(comp.\\g<2>(), color=False)",
    "shell_completion.py", 2,
)
path.write_text(text)

print("OK: solucao extra aplicada em termui.py e shell_completion.py")
