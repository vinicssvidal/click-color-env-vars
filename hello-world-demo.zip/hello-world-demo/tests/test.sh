#!/bin/bash
# Correctness rubrics only: leave this file as is. It always reports success so the trial
# completes, and your correctness rubrics decide correctness.
# If you write tests (tests only, or tests and correctness rubrics), replace this file with
# your own test.sh. Start from test.sh.example in this folder.
# The model patch is captured by the task.toml [[verifier.collect]] hook, not here.
mkdir -p /logs/verifier
echo 1 > /logs/verifier/reward.txt
